@extends('layouts.app')

@section('content')
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">{{ __('Dashboard') }}</h1>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body bg-success">
                        <p class="card-text">
                            {{ __('Selamat Datang !') }} {{ auth()->user()->nama }}
                        </p>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body text-center">
                        <img src="https://glints.com/id/lowongan/wp-content/uploads/2018/01/pexels-thirdman-7652178.jpg">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->
@endsection